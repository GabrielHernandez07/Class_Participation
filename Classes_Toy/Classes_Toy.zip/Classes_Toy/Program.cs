﻿using System;

namespace Classes_Toy
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

        public string Manufacturer { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        private string Notes { get; set; }
        //public Toy()
        //{ 
        //    Manufacturer = string.Empty;
        //    Name = string.Empty;
        //    Price = 0;
        //    Notes = string.Empty;
        //}
        public string GetAisle()
        {
            Random rand = new Random();
            int randomNumber = rand.Next(1, 25);
            string manuFirstLetter = Manufacturer;
            manuFirstLetter = "" + manuFirstLetter.ToUpper() + manuFirstLetter.Trim();
            Console.WriteLine(manuFirstLetter);
            string manuLetterandNumber = $"{manuFirstLetter}{randomNumber}";
            return manuLetterandNumber;
        }


    }
}
